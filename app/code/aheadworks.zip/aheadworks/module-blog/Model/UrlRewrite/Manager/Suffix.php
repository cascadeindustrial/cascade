<?php
namespace Aheadworks\Blog\Model\UrlRewrite\Manager;

use Aheadworks\Blog\Model\UrlRewrite\MetadataInterface;
use Aheadworks\Blog\Model\UrlRewrite\Updater\Suffix as SuffixUpdater;
use Magento\Framework\Exception\LocalizedException;
use Aheadworks\Blog\Model\Config;

/**
 * Class Suffix
 * @package Aheadworks\Blog\Model\UrlRewrite\Manager
 */
class Suffix
{
    /**
     * @var SuffixUpdater
     */
    private $suffixUpdater;

    /**
     * @var Config
     */
    private $config;

    /**
     * @param SuffixUpdater $suffixUpdater
     * @param Config $config
     */
    public function __construct(
        SuffixUpdater $suffixUpdater,
        Config $config
    ) {
        $this->suffixUpdater = $suffixUpdater;
        $this->config = $config;
    }

    /**
     * Update suffix
     *
     * @param MetadataInterface $metadata
     * @return void
     * @throws LocalizedException
     */
    public function update($metadata)
    {
        if ($this->config->getSaveRewritesHistory()) {
            foreach ($metadata->getStoreIds() as $storeId) {
                $this->suffixUpdater->update(
                    $storeId,
                    $metadata
                );
            }
        }
    }
}
