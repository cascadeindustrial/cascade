<?php
namespace Aheadworks\Blog\Model\UrlRewrite\Metadata;

use Aheadworks\Blog\Model\UrlRewrite\MetadataInterface;
use Magento\Framework\Exception\LocalizedException;

/**
 * Interface CreatorInterface
 *
 * @package Aheadworks\Blog\Model\UrlRewrite\Metadata
 */
interface CreatorInterface
{
    /**
     * Create metadata
     *
     * @param mixed $entity
     * @param string $originalUrlKey
     * @return MetadataInterface[]
     * @throws LocalizedException
     */
    public function create($entity, $originalUrlKey);
}
