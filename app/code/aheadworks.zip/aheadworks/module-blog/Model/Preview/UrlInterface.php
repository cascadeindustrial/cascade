<?php
namespace Aheadworks\Blog\Model\Preview;

use Magento\Framework\UrlInterface as FrameworkUrlInterface;

/**
 * Interface UrlInterface
 * @package Aheadworks\Blog\Model\Preview
 */
interface UrlInterface extends FrameworkUrlInterface
{
}
