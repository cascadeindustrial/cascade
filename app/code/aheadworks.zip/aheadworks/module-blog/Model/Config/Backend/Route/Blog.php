<?php
namespace Aheadworks\Blog\Model\Config\Backend\Route;

use Aheadworks\Blog\Model\Config\Backend\AbstractRoute;
use Aheadworks\Blog\Model\Source\UrlRewrite\RouteType;

/**
 * Class Blog
 * @package Aheadworks\Blog\Model\Config\Backend\Route
 */
class Blog extends AbstractRoute
{
    /**
     * {@inheritDoc}
     */
    public function getRouteType()
    {
        return RouteType::TYPE_BLOG;
    }
}
