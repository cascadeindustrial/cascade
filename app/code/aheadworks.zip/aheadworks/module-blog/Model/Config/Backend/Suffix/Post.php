<?php
namespace Aheadworks\Blog\Model\Config\Backend\Suffix;

use Aheadworks\Blog\Model\Source\UrlRewrite\EntityType;
use Aheadworks\Blog\Model\Config\Backend\AbstractSuffix;

/**
 * Class Post
 * @package Aheadworks\Blog\Model\Config\Backend\Suffix
 */
class Post extends AbstractSuffix
{
    /**
     * {@inheritDoc}
     */
    public function getEntityType()
    {
        return EntityType::TYPE_POST;
    }
}
