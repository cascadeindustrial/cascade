<?php
namespace Aheadworks\Blog\Model\Config\Backend\Route;

use Aheadworks\Blog\Model\Config\Backend\AbstractRoute;
use Aheadworks\Blog\Model\Source\UrlRewrite\RouteType;

/**
 * Class Author
 * @package Aheadworks\Blog\Model\Config\Backend\Route
 */
class Author extends AbstractRoute
{
    /**
     * {@inheritDoc}
     */
    public function getRouteType()
    {
        return RouteType::TYPE_AUTHOR;
    }
}
