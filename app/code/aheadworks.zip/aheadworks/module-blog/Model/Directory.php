<?php
namespace Aheadworks\Blog\Model;

/**
 * Class DirectoryList
 */
class Directory
{
    /**
     * Export folder
     */
    const AW_BLOG_EXPORT = 'aw_blog_export';
}