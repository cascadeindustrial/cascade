<?php
namespace Aheadworks\Blog\Model\Post;

use Aheadworks\Blog\Api\Data\PostInterface;
use Aheadworks\Blog\Model\Post\Listing\Builder as PostListBuilder;
use Aheadworks\Blog\Model\Source\Post\Status;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class Collector
 */
class Collector
{
    /**
     * @var PostListBuilder
     */
    private $postListBuilder;

    /**
     * @var DateTime
     */
    private $dateTime;

    /**
     * @param PostListBuilder $postListBuilder
     * @param DateTime $dateTime
     */
    public function __construct(
        PostListBuilder $postListBuilder,
        DateTime $dateTime
    ) {
        $this->postListBuilder = $postListBuilder;
        $this->dateTime = $dateTime;
    }

    /**
     * Collect scheduled posts
     *
     * @return PostInterface[]
     * @throws LocalizedException
     */
    public function collectScheduledPosts()
    {
        $now = $this->dateTime->gmtDate(\Magento\Framework\Stdlib\DateTime::DATETIME_PHP_FORMAT);

        $this->postListBuilder
            ->getSearchCriteriaBuilder()
            ->addFilter(PostInterface::STATUS, Status::SCHEDULED)
            ->addFilter(PostInterface::PUBLISH_DATE, $now, 'lteq');

        return $this->postListBuilder->getPostList();
    }
}
