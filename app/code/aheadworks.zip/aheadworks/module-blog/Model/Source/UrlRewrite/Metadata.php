<?php
namespace Aheadworks\Blog\Model\Source\UrlRewrite;

/**
 * Class Metadata
 * @package Aheadworks\Blog\Model\Source\UrlRewrite
 */
class Metadata
{
    /**#@+
     * Metadata types for url rewrites
     */
    const REWRITE_METADATA_POST_CATEGORY = 'category_id';
    /**#@-*/
}
