<?php
// @codeCoverageIgnoreStart
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Aheadworks_Blog',
    __DIR__
);
// @codeCoverageIgnoreEnd
