var config = {
    config: {
        mixins: {
            'Magento_ConfigurableProduct/js/configurable': {
                'Dcw_SimpleSku/js/model/skuswitch': true
            }
        }
    }
};