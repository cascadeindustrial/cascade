<?php
/**
 *
 * @copyright   Copyright (c) 2018 DotcomWeavers
 * @author
 * @package     Dcw_PopularProducts
 *
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Dcw_HeaderDesign',
    __DIR__
);
