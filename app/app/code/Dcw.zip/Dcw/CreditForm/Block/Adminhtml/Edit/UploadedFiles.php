<?php
namespace Dcw\CreditForm\Block\Adminhtml\Edit;


class UploadedFiles extends \Magento\Backend\Block\Template
{
    /**
 	* Block template.
 	*
 	* @var string
 	*/
    protected $_template = 'uploadedfiles.phtml';

}
