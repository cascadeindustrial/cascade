<?php
namespace Dcw\CustomPricing\Block\Adminhtml\Order\View;
class Custom extends \Magento\Backend\Block\Template
{

}
