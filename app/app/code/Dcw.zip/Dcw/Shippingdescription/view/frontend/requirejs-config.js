var config = {
    map: {
        '*': {
            'Magento_Checkout/template/shipping-address/shipping-method-item.html': 'Dcw_Shippingdescription/template/shipping-address/shipping-method-item.html'
        }
    }
};